#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    char str[100];

    ofstream outfile("Test.txt", ios::out);

        cout<<"Enter any text.";
        gets(str);

        outfile<<str;

    outfile.close();

    return 0;
}
