#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    //writing in a file
    ofstream ofs("Test.txt", ios::app);

    ofs<<"Garima"<<endl;
    ofs<<25<<endl;
    ofs<<"Pandey"<<endl;
    ofs<<"Welcome Garima Pandey.";

    ofs<<"Madhva"<<endl;
    ofs<<25<<endl;
    ofs<<"Aakash"<<endl;
    ofs<<"Welcome Madhav and Aakash.";

    ofs.close();

    return 0;
}
