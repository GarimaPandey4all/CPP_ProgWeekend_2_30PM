#include <iostream>
#include <array>

using namespace std;

int main()
{
    //array<int, 5> data_array; //declaration

    array<int, 5> data_array = {10, 20, 30, 40, 50}; //declaration and initialization
    array<int, 5> data_array2 = {1, 2, 3, 4, 5}; //declaration and initialization

    //at()

    cout<<"Value is:"<<data_array.at(1)<<endl;

    //[]operator

    cout<<"Value is:"<<data_array[4]<<endl;

    //front()

    cout<<"First value of array is:"<<data_array.front()<<endl;

    //back()

    cout<<"Last value of array is:"<<data_array.back();

    //fill()

//    data_array.fill(60);
//
//    cout<<"After fill() the values in array are:";
//    for(int i=0; i<8; i++)
//        cout<<data_array[i]<<endl;

    //array1.swap(array2);
    data_array.swap(data_array2);

    cout<<"Array 1:"<<endl;
    for(int i=0; i<5; i++)
        cout<<data_array[i]<<endl;

    cout<<"Array 2:"<<endl;
    for(int j=0; j<5; j++)
        cout<<data_array2[j]<<endl;

    cout<<"Size of Array 1:"<<data_array.size();


    return 0;
}
