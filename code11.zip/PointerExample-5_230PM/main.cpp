#include <iostream>

using namespace std;

int main()
{
    int value = 10;

    int *pvalue = NULL;

    pvalue = &value;

    cout<<"Value is:"<<*pvalue<<endl;

    int number = 20;

    pvalue = &number;

    cout<<"Value is:"<<*pvalue<<endl;

    cout<<"Size of *pvalue is:"<<sizeof(*pvalue);

    return 0;
}
