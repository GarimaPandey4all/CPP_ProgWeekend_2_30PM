#include <iostream>

using namespace std;

int main()
{
    //pointer to a constant

    int value = 10;

    int number = 20;

    const int *pvalue = NULL; //pointer to a constant //value can't be changed.

    pvalue = &value; //okay

    //*pvalue = 20; //error;

    pvalue = &number;

    cout<<"Value is:"<<*pvalue;

    return 0;
}
