#include <iostream>

using namespace std;

int main()
{
    int value = 0;
    int *pvalue = NULL;

    pvalue = &value;

    cout<<"Enter any value:";
    cin>>*pvalue;

    cout<<"Value is:"<<value<<endl;

    cout<<"Value is:"<<*pvalue;

    return 0;
}
