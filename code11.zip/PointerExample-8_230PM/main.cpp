#include <iostream>

using namespace std;

int main()
{
    int value = 0;
    int *pt = &value; //pointer declaration

    *pt = 5; //Dereferencing

    return 0;
}
