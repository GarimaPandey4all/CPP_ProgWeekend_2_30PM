#include <iostream>

using namespace std;

int main()
{
    //pointer to a constant

    const int value = 10;

    int number = 20;

    const int *const pvalue = &value; //pointer to a constant //value can't be changed.

//    value = 20; //error
//
//    *pvalue = 30; //error
//
//    pvalue = &number; //error

    cout<<"Value is:"<<*pvalue;

    return 0;
}
