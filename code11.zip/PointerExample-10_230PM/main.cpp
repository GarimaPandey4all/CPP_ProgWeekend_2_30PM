#include <iostream>

using namespace std;

int main()
{
    //pointer to a constant

    int value = 10;

    int number = 20;

    int *const pvalue = &value; //constant pointer //address can't be changed.

    //pvalue = &value; //error

    *pvalue = 20; //error;

    //pvalue = &number; //error

    cout<<"Value is:"<<*pvalue;

    return 0;
}
