
/*
    Function has four types in C++:

    1. Function without arguments and without return value
    2. Function with arguments and without return value
    3. Function without arguments and with return value
    4. Funciton with arguments and with return value

*/


/*

a, b;

c = a+b;

printf(c);

*/

/*

    function_Prototype:

    return_type function_name(); //declaration of function

    return_type function_name(int, int) //function definition
    {

            //function body
    }

    int main()
    {
        //calling of function
    }

*/

