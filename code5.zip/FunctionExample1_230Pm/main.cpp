#include <iostream>

using namespace std;

//Function without arguments and without return value

void Sum();

void Sum()
{
    int a, b;

    cout<<"Enter value for a and b:";
    cin>>a>>b;

    cout<<"Addition of Two numbers:"<<a+b;
}

int main()
{

    Sum();
    return 0;
}
