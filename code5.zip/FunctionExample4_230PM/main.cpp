#include <iostream>

using namespace std;

//Function with arguments and with return value

int Sum(int, int);

int main()
{
    //int x,y;
    int a, b;
    Sum(a,b);
    Sum(a,b);
    Sum(a,b);
    Sum(a,b);
    //cout<<"Addition of Two Numbers:"<<result;
    return 0;
}

int Sum(int a, int b)
{
     cout<<"Enter value for a and b:";
     cin>>a>>b;

    cout<<"Addition of Two numbers:"<<a+b;

    return 0;

}
