#include <iostream>

/*
    int main(int argc, char *argv[])

    main(4,(program_name, Garima, 10, 19))

1. Argument Count
2. Argument vector: character of pointer

*/

using namespace std;

int main(int argc, char *argv[])
{
    int i;
    for(i=0; i<argc; i++)
        cout<<"Arguments are:"<<argv[i]<<endl;
        cout<<"Argument count is:"<<argc;

    return 0;
}
