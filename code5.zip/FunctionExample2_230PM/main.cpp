#include <iostream>

using namespace std;

//Function with arguments and without return value

void Sum(int, int);

void Sum(int a, int b)
{
    cout<<"Addition of Two numbers:"<<a+b;
}

int main()
{
    Sum(10, 8);
    Sum(10, 8);
    Sum(10, 8);
    Sum(10, 8);
    return 0;
}
