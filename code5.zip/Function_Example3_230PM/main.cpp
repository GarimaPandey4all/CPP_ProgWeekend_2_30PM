#include <iostream>

using namespace std;

//Function without arguments and with return value

int Sum();

int main()
{
    int result;
    result=Sum();
    cout<<"Addition of Two Numbers:"<<result;
    return 0;
}

int Sum()
{
    int a, b;

    cout<<"Enter value for a and b:";
    cin>>a>>b;

    //cout<<"Addition of Two numbers:"<<a+b;

    return a+b;

}
