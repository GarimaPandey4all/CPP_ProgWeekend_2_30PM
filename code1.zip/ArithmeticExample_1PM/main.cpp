#include <iostream>

using namespace std;

int main()
{
    int A, B, C;

    cout<<"Enter any Value for a:";
    cin>>A;

    cout<<"Enter any Value for b:";
    cin>>B;

    //Arithmetic Operators

    C = A + B;

    cout<<"Addition is:"<<C<<endl;

    C = A - B;

    cout<<"Subtraction is:"<<C<<endl;

    C = A * B;

    cout<<"Multiplication is:"<<C<<endl;

    C = A / B;

    cout<<"Division is:"<<C<<endl;

    C = A % B;

    cout<<"Modulus is:"<<C<<endl;

    //Pre and Post Increment

    cout<<"Pre-Increment is:"<<++A<<endl; // A = 11, 12

    cout<<"Post-Increment is:"<<A++<<endl; // A = 12,

    cout<<"A is:"<<A<<endl;

    cout<<"Pre-Decrement is:"<<--B<<endl; // B = 9

    cout<<"Post-Decrement is:"<<B--<<endl;

    cout<<"B is:"<<B;

    return 0;
}
