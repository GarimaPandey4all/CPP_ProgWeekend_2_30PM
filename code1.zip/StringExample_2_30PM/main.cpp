#include <iostream>

using namespace std;

int main()
{
    //string name;
    string FirstName, LastName;

//    cout<<"May i know your name: ";
//    //cin>>name;
//    getline(cin, name);

    //cout<<"Name is: "<<name;

    cout<<"Enter your First Name:";
    cin>>FirstName;

    cout<<"Enter your Last Name:";
    cin>>LastName;

    cout<<"Name is: "<<FirstName <<" "<< LastName;

    return 0;
}
