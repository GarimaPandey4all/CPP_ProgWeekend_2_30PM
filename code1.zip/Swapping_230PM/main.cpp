#include <iostream>

using namespace std;

int main()
{
    // Swapping Using third variable

    int a=7, b=9, temp;

    cout<<"Before Swapping "<<a<<" and "<<b<<endl;

//    temp = a;
//    a = b;
//    b = temp;
//
//    cout<<"After Swapping "<<a<<" and "<<b<<endl;


    // Swapping without using third variable

    //Second Way: + and -

//    a = a + b;
//    b = a - b;
//    a = a - b;
//
//    cout<<"After Swapping "<<a<<" and "<<b<<endl;

    //Third Way: * and /

    a = a * b;
    b = a / b;
    a = a / b;

    cout<<"After Swapping "<<a<<" and "<<b<<endl;

    return 0;
}
