#include <iostream>

using namespace std;

int main()
{
    int a, b, c, Largest;

    cout<<"Enter value for a:";
    cin>>a;

    cout<<"Enter value for b:";
    cin>>b;

    cout<<"Enter value for c:";
    cin>>c;

    Largest = (a>b) ? ((a>c)? a:c) : ((b>c)? b:c);

    cout << "Largest number is: "<<Largest << endl;
    return 0;
}
