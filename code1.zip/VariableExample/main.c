#include <stdio.h>
#include <stdlib.h>

int main()
{
    const int a = 10;

//    a = 20;
//
//    a = 30;

    printf("A is: %d", a);

    return 0;
}
