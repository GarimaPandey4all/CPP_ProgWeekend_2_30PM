#include <iostream>

using namespace std;

int main()
{
    int A=7, B=9;

    //A --> 0000 0111, B--> 0000 1001

    cout<<"Bitwise AND Operator is:"<<(A & B)<<endl; //1

    cout<<"Bitwise OR Operator is:"<<(A | B)<<endl; // 15

    cout<<"Bitwise X-OR Operator:"<<(A ^ B)<<endl; // 14

    cout<<"Left Shift is:"<<(A<<2)<<endl; // 7 * 4=28

    cout<<"Right Shift is:"<<(B>>2); // 9 / 4= 2

    return 0;
}
