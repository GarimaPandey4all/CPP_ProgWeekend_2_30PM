#include <stdio.h>
#include <stdlib.h>

int main()
{
    int A, B, C;

    //Arithmetic Operators

    printf("Enter any value for A:");
    scanf("%d", &A);

    printf("Enter any value for B:");
    scanf("%d", &B);

    C = A + B;

    printf("Addition is: %d\n", C);

    C = A - B;

    printf("Subtraction is: %d\n", C);

    C = A * B;

    printf("Multiplication is: %d\n", C);

    C = A / B;

    printf("Division is: %d\n", C);

    C = A % B;

    printf("Modulus is: %d\n", C);

    printf("Pre-Increment: %d\n", ++A); //A = 23

    printf("Post-Increment: %d\n", A++); // A = 24

    printf("A is: %d\n", A); //A= 25

    printf("Pre-Decrement: %d\n", --B); //B = 12

    printf("Post-Decrement: %d\n", B--);

    printf("B is: %d\n", B);

    return 0;
}
