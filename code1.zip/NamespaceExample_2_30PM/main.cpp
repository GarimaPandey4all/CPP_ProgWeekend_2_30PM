#include <iostream>

using namespace std;

namespace dataType
{
    int value = 200;

    void showdata()
    {
        cout<<"Hello World\n";
    }
}

namespace dataType1
{
    int value = 700;

}

void showdata();

//Global variable

int value = 500;

int main()
{
    //local variable
    int value =100;

    cout <<"Value is"<<value<< endl;

    cout<<dataType::value<<endl;

    cout<<dataType1::value<<endl;

    dataType::showdata();

    showdata();

    return 0;
}

void showdata(){
    cout<<"Value is:"<<value<<endl;
}
