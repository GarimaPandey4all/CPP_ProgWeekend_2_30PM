#include <iostream>

using namespace std;

int main()
{
    int a;
    char b;
    float c;
    double d;

    cout << "Size of Int "<<sizeof(a) << endl;
    cout << "Size of Char "<<sizeof(b) << endl;
    cout << "Size of Float "<<sizeof(c) << endl;
    cout << "Size of Double "<<sizeof(d) << endl;

    return 0;
}
