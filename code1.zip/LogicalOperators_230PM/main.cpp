#include <iostream>

using namespace std;

int main()
{
    int A, B;

    cout<<"Enter value for A:";
    cin>>A;

    cout<<"Enter value for B:";
    cin>>B;

    //Logical Operators

    if(A && B)
        cout<<"This is A && B\n";

    if(A || B)
        cout<<"This is A || B\n";

    if(!(A && B))
       cout<<"This is !(A && B)";

    return 0;
}
