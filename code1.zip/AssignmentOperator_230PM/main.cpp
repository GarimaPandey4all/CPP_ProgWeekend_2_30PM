#include <iostream>

using namespace std;

int main()
{
    int array[5], i, sum=0;

    cout<<"Enter 5 Marks:";
    for(i=0; i<5; i++)
    cin>>array[i];

    for(i=0; i<5; i++)
        sum += array[i]; //sum = sum + array[];

    cout << "Sum is:"<<sum << endl;

    return 0;
}
