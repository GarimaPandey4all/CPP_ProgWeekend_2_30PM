#include <iostream>

using namespace std;

int main()
{
    int A=5, B=9;

    // 5--> 0000 0101, B--> 0000 1001 = 0000 1100

    cout<<"Before Swapping "<<A<<" and "<<B<<endl;

    A = A ^ B; // 12
    B = A ^ B; // 5
    A = A ^ B; // 9

    cout<<"After Swapping "<<A<<" and "<<B<<endl;

    return 0;
}
