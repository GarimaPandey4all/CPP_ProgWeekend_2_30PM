#include <stdio.h>
#include <stdlib.h>

int main()
{
    char symbol;

    printf("Enter any character:");
    scanf("%c", &symbol);

    printf("Entered character's decimal is:%d", symbol);

    return 0;
}
