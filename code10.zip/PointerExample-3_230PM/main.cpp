#include <iostream>

using namespace std;

int main()
{
    int count = 10, x;

    int *pcount = NULL;

    pcount = &count;

    x = *pcount;

    cout<<"Count is:"<<count<<" and X is:"<<x;

    return 0;
}
