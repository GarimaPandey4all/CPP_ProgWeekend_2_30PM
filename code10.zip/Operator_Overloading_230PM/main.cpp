#include <iostream>

using namespace std;

class Complex
{
private:
    int real;
    int imag;

public:
    Complex(int r=0, int i=0)
    {
        real = r;
        imag = i;
    }

Complex operator + (Complex obj)
{
    Complex temp;
    temp.real = real + obj.real;
    temp.imag = imag + obj.imag;
    return temp;
}

void print()
{
    cout<<real<<" + i"<<imag<<endl;
}

};

int main()
{
    Complex C1(4,5);
    Complex C2(2,3);
    Complex C3=C1+C2; //C3 = C1.add(C2)
    C3.print();
    return 0;
}
