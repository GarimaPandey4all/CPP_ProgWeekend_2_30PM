#include <iostream>

using namespace std;

int main()
{
    int value = 99;

    int *pvalue = NULL;

    int result = 0;

    pvalue = &value;

    result = *pvalue + 10;

    //result = pvalue + 10; //error

    *pvalue += 10; //

    cout<<"Result is:"<<result<<endl;

    cout<<"Value is:"<<*pvalue<<endl;

    cout<<"Value is:"<<value;

    return 0;
}
