#include <iostream>

using namespace std;

int main()
{
    int value = 99;

    int *pvalue = &value;

    *pvalue = 100;

    cout<<"Value is:"<<*pvalue; //indirection operator/Dereference operator

    return 0;
}
