#include <iostream>

using namespace std;

int main()
{
    int value = 10;

    int *pvalue = NULL;

    pvalue = &value;

    cout<<"Value is:"<<*pvalue<<endl;

    cout<<"Value is:"<<pvalue;

    return 0;
}
