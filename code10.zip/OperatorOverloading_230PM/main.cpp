#include <iostream>

using namespace std;

class Complex
{
private:
    int real;
    int imag;

public:
    Complex(int r=0, int i=0)
    {
        real = r;
        imag = i;
    }

};

int main()
{
    Complex C1(4,7);
    Complex C2(2,3);
    Complex C3;
    C3 = C1 + C2; //C1.add(C2);
    return 0;
}
