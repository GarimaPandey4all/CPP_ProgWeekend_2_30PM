#include <iostream>

using namespace std;

int main()
{
    int n, sum=0, r, temp;

    cout<<"Enter number to check whether the number is Palindrome or not?:";
    cin>>n;

    temp = n;

    while(n>0)
    {
        r = n%10; //n= 5225, 5, 2, 2, 5
        sum = sum * 10 + r; //sum= 5, 52, 522, 5225
        n = n/10; //n=522, 52, 5, 0
    }

    n = temp;

    (n==sum)?cout<<"Palindrome Number": cout<<"Not a Palindrome number";

    return 0;
}
