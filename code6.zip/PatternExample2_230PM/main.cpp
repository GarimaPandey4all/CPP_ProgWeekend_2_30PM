#include <iostream>

using namespace std;

int main()
{
    char i , j;

    for(i='A'; i<='E'; i++)
    {
        for(j='A'; j<='E'; j++)
        {
            cout<<i;
            //cout<<j;
        }
        cout<<endl;
    }

    return 0;
}
