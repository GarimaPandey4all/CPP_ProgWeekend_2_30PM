#include <iostream>

using namespace std;

int main()
{
    char i , j;

    for(i='e'; i>='a'; i--)
    {
        for(j=i; j>='a'; j--)
        {
            //cout<<"*";
            //cout<<i;
            cout<<j;
        }
        cout<<endl;
    }

    return 0;
}
