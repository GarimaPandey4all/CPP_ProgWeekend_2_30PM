#include <iostream>

using namespace std;

int main()
{
    int n, reverse=0, r;

    cout<<"Enter any number:";
    cin>>n;

    while(n>0)
    {
        r = n%10; //n= 5225, 5, 2, 2, 5
        reverse = reverse * 10 + r; //sum= 5, 52, 522, 5225
        n = n/10; //n=522, 52, 5, 0
    }

    cout<<"Reverse Number is:"<<reverse;

    return 0;
}
