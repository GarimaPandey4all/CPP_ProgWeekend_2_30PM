#include <iostream>

using namespace std;

int main()
{
    int n, sum=0, r;

    cout<<"Enter any number:";
    cin>>n;

    while(n>0)
    {
        r = n%10; //n= 123, 3, 2, 1
        sum = sum + r; //sum= 3
        n = n/10; //n=1
    }

    cout<<"Sum of Digits are:"<<sum;

    return 0;
}
