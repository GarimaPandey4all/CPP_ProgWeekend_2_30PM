#include <iostream>

using namespace std;

class Calculator
{
public:

    void Add(int a, int b)
    {
        cout<<"Addition of Integers:"<<a+b<<endl;
    }

    void Add(float x, float y)
    {
        cout<<"Addition of Floating Values:"<<x+y<<endl;
    }

    void Add(double a, double b)
    {
        cout<<"Addition of Double values:"<<a+b;
    }

    void Sub(int a, int b)
    {
        cout<<"Subtraction of Integers:"<<a-b<<endl;
    }

    void Sub(float x, float y)
    {
        cout<<"Subtraction of Floating Values:"<<x-y<<endl;
    }

    void Mul(int a, int b)
    {
        cout<<"Multiplication of Integers:"<<a*b<<endl;
    }

    void Mul(float x, float y)
    {
        cout<<"Multiplication of Floating Values:"<<x*y<<endl;
    }

    void Div(int a, int b)
    {
        cout<<"Division of Integers:"<<a/b<<endl;
    }

    void Div(float x, float y)
    {
        cout<<"Division of Floating Values:"<<x/y<<endl;
    }

};

int main()
{
    Calculator obj;

    obj.Add(10, 20);
    obj.Add(10.2f, 15.8f);
    obj.Add(24.7, 78.9);

    obj.Sub(10, 5);
    obj.Sub(40.8f, 10.9f);

    obj.Div(10, 2);
    obj.Div(10.0f, 20.0f);

    obj.Mul(2, 7);
    obj.Mul(10.2f, 70.9f);

    return 0;
}
