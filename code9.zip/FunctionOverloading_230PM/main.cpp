#include <iostream>

using namespace std;

class func_Overloading
{
public:

    void func(int a)
    {
        cout<<"A is:"<<a<<endl;
    }

    void func(int x, int y)
    {
        cout<<"X is:"<<x<<" and Y is:"<<y<<endl;
    }

    void func(float z)
    {
        cout<<"Z is:"<<z;
    }
};

int main()
{
    func_Overloading f1;

    f1.func(10);
    f1.func(10, 20);
    f1.func(50.6f);

    return 0;
}
