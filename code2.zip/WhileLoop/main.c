#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i;

    i = 0;
    while(i<10)
    {
        printf("Counter is:%d\n", i+1);
        i++;
    }

    return 0;
}
