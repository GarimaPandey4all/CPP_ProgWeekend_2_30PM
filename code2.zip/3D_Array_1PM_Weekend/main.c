#include <stdio.h>
#include <stdlib.h>

int main()
{
    int array1[2][2][2], array2[2][2][2], array3[2][2][2],i,j,k;

    printf("Enter any values in Array1:\n");
    for(i=0; i<2; i++)
    {
        for(j=0; j<2; j++)
        {
            for(k=0; k<2; k++)
            {
                    scanf("%d", &array1[i][j][k]);
            }
        }
    }

    printf("Enter any values in Array2:\n");
    for(i=0; i<2; i++)
    {
        for(j=0; j<2; j++)
        {
            for(k=0; k<2; k++)
            {
                    scanf("%d", &array2[i][j][k]);
            }
        }
    }

    printf("Enter any values in Array3:\n");
    for(i=0; i<2; i++)
    {
        for(j=0; j<2; j++)
        {
            for(k=0; k<2; k++)
            {
                    scanf("%d", &array3[i][j][k]);
            }
        }
    }


    printf("Enter any values in Array1:\n");
    for(i=0; i<2; i++)
    {
        for(j=0; j<2; j++)
        {
            for(k=0; k<2; k++)
            {
                    printf("%d  ", array1[i][j][k]);
            }
        }
    }

    printf("\nEnter any values in Array2:\n");
    for(i=0; i<2; i++)
    {
        for(j=0; j<2; j++)
        {
            for(k=0; k<2; k++)
            {
                    printf("%d  ", array2[i][j][k]);
            }
        }
    }

    printf("\nEnter any values in Array3:\n");
    for(i=0; i<2; i++)
    {
        for(j=0; j<2; j++)
        {
            for(k=0; k<2; k++)
            {
                    printf("%d  ", array3[i][j][k]);
            }
        }
    }


    return 0;
}
