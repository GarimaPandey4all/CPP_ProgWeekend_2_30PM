

/*Loops:

    1. For Loop

        Syntax: for(initialization; condition; increment/decrement)
                {
                    statements
                }

    2. While Loop

        Syntax: initialization

        while(condition)
        {

        increment/decrement
        }

    3. Do While Loop

    Syntax: initialization

    do
    {

    increment/decrement
    }while(condition);

*/
