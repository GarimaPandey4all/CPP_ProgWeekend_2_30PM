#include <stdio.h>
#include <stdlib.h>

int main()
{
    int array[3]; //declaration of Array

    int array[3] = {4, 6}; //traditional way

    int array[] = {4,6,8,8,9,9,90,0,0}; //compile time array memory allocation

    int array[5] = {3, 6, [3]=9}; //designated way

    int array[][2] = {{2, 5},
                        {4,7}};

    return 0;
}
