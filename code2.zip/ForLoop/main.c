#include <stdio.h>
#include <stdlib.h>
#define TABLE 10

int main()
{
    int i, n;

    printf("Enter any number to print the table:");
    scanf("%d", &n);

    printf("Table of %d\n", n);

    for(i=1; i<=TABLE; i++)
        printf("%d * %d = %d\n", n, i, n * i);

    return 0;
}
