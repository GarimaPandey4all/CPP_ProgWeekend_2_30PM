#include <iostream>

using namespace std;

class Abstraction
{
private:
    int a, b;

public:
    //setter
    void setAdd(int x, int y)
    {
        a = x;
        b = y;
    }

    //getter
    void getDisplay()
    {
        cout<<"Addition is:"<<a+b;
    }
};

int main()
{
    Abstraction A1;
    A1.setAdd(10, 30);
    A1.getDisplay();
    return 0;
}
