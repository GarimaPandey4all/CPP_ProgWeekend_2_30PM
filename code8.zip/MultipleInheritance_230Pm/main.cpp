#include <iostream>

using namespace std;

class parent1
{
    public:
    int parent1;
};

class parent2
{
public:
    int parent2;
};

class child : public parent1 , public parent2
{
public:
    int child;
};

int main()
{
    child C1;

    C1.child = 10;
    C1.parent1 = 20;
    C1.parent2 = 30;

    cout<<"Child is:"<<C1.child<<endl;
    cout<<"Parent1 is:"<<C1.parent1<<endl;
    cout<<"Parent2 is:"<<C1.parent2<<endl;

    return 0;
}
