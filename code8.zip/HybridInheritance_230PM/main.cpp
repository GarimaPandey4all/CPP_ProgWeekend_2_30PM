#include <iostream>

using namespace std;

/*
    Hybrid Inheritance:

    combination of Multiple + Heirachical Inheritance

*/

class Vehicle
{
public:

    Vehicle()
    {
        cout<<"This is Vehicle."<<endl;
    }

};

class FourWheeler
{
public:
    FourWheeler()
    {
        cout<<"This is FourWheeler."<<endl;
    }
};

//Multiple Inheritance
class Car : public Vehicle, public FourWheeler
{
public:
    Car()
    {
        cout<<"This is Car."<<endl;
    }
};

class Bus : public Vehicle
{
public:
    Bus()
    {
        cout<<"This is Bus."<<endl;
    }
};


int main()
{
    Car C;
    Bus B;
    return 0;
}
