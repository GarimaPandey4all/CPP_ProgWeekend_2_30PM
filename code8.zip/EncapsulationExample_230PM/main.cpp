#include <iostream>

using namespace std;

class Encapsulation
{
public:
    int x;

    void display()
    {
        cout<<"x is:"<<x;
    }
};

int main()
{
    Encapsulation E1;

    E1.x=10;

    E1.display();

    return 0;
}
