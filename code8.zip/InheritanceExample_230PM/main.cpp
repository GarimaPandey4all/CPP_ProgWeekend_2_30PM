#include <iostream>

using namespace std;

/*
    Inheritance has five types:

    1. Single
    2. Multiple
    3. Multilevel
    4. Heirarchical
    5. Hybrid

*/

//Base Class
class parent
{
public:
    int id_parent;
};


//Derived Class

class child : public parent
{
public:
    int id_child;
};

int main()
{
    child C1;
    C1.id_child = 10;
    C1.id_parent = 20;

    cout<<"Child is:"<<C1.id_child<<endl;
    cout<<"Parent is:"<<C1.id_parent<<endl;

    return 0;
}
