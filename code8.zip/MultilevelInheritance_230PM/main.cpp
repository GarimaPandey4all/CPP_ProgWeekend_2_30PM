#include <iostream>

using namespace std;

class Parent
{
public:
    int parent;
};

class child1 : public Parent{
public:
    int child1;

};

class child2 : public child1{
public:

    int child2;
};


int main()
{
    child2 C1;
    C1.child2 = 2;
    C1.child1 = 4;
    C1.parent = 6;


    cout<<"Parent is:"<<C1.parent<<endl;
    cout<<"Child1 is:"<<C1.child1<<endl;
    cout<<"Child2 is:"<<C1.child2<<endl;


    return 0;
}
