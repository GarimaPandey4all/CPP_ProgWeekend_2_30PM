#include <iostream>
#include <vector>

using namespace std;

int main()
{
    //vector <int> V1; //only for declare of vector

    vector <string> V1{"Garima", "Pandey", "C++"}; //declaration & Initialization

    cout<<"Current Capacity is:"<<V1.capacity();


    return 0;
}
