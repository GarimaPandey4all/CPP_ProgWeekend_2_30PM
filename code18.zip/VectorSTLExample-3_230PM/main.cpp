#include <iostream>
#include <vector>

using namespace std;

int main()
{
    vector <int> V1;

    cout<<"Current Capacity is:"<<V1.capacity()<<endl;

    for(int i=0; i<10; i++)
        V1.push_back(10*(i+1));

    cout<<"Values in vector:\n";
//    for(int i=0; i<10; i++)
//        cout<<V1[i]<<endl;

    for(int i=0; i<V1.size(); i++)
        cout<<V1[i]<<endl;

    cout<<"Current Size is:"<<V1.size()<<endl;
    cout<<"Current Capacity is:"<<V1.capacity()<<endl;

    V1.pop_back();

    cout<<"Values in vector after pop_back():\n";
    for(int i=0; i<V1.size(); i++)
        cout<<V1[i]<<endl;

    cout<<"Current Capacity is:"<<V1.capacity()<<endl;

    cout<<"Current Size is:"<<V1.size()<<endl;

    return 0;
}
