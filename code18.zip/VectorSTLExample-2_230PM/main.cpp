#include <iostream>
#include <vector>

using namespace std;

int main()
{
    vector <int> V1;
    vector <char> V2(4);
    vector <int> V3(5, 10);
    vector <string> V4(4, "Hi");

    //Subscript operator[]

    cout<<V4[0]<<endl;
    cout<<V4[1]<<endl;
    cout<<V4[2]<<endl;
    cout<<V4[3]<<endl;

    //at(), front(), and back()

    cout<<"At():"<<V1.at(5)<<endl;
    cout<<"Front():"<<V1.front()<<endl;
    cout<<"Back():"<<V1.back()<<endl;


    return 0;
}
