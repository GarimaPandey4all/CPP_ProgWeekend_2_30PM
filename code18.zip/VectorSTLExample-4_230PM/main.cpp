#include <iostream>
#include <vector>

using namespace std;

int main()
{
    vector <int> V1;

    for(int i=0; i<10; i++)
        V1.push_back(10*(i+1));

    for(int i=0; i<V1.size(); i++)
       cout<<V1[i]<<endl;

       cout<<endl<<endl;

       //Insert at particular location

    vector <int>:: iterator itr = V1.begin();

    V1.insert(itr + 3, 35);

    for(int i=0; i<V1.size(); i++)
       cout<<V1[i]<<endl;

    V1.clear();

    cout<<"Size of Vector 1:"<<V1.size();

    return 0;
}
