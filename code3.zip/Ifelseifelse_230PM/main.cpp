#include <iostream>

using namespace std;


/*
        if()
        {

        }
        else
        {

        }

        if()

        {}
        else if()
        {

        }else if()
        {

        }else if()
        {

        }else if()
        {

        }else if()
        {

        }else if()
        {

        }
        else
        {}

*/

int main()
{
    int scores[5], sum=0,i, percentage;

    cout<<"Please enter your score for all subjects:";
    for(i=0; i<5; i++)
    cin>>scores[i];


    for(i=0; i<5; i++)
    {
        sum += scores[i];
    }
    cout<<"Sum is:"<<sum<<endl;

    percentage = sum /5;

    cout<<"Percentage is:"<<percentage<<endl;


    if(percentage>=50 && percentage <=60)
        cout<<"D Grade";

    else if(percentage>=60 && percentage <=70)
        cout<<"C Grade";

    else if(percentage>=70 && percentage <=80)
        cout<<"B Grade";

    else if(percentage>=80 && percentage <=100)
        cout<<"A Grade";

    else
        cout<<"Otherwise Fail...";

    return 0;
}
