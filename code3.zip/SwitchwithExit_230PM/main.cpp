#include <iostream>

using namespace std;

int main()
{
    int choice;
    int a=10, b=40;
    int c=4, d=9;
    int Largest, e=9, f=8, g=10;
    int n=5;
    int n1=5;


    while(1)
        {
    cout<<"Press 1. for Addition\n";
    cout<<"Press 2. for X-OR\n";
    cout<<"Press 3. for Even-Odd\n";
    cout<<"Press 4. for Largest Number\n";
    cout<<"Press 5. for Left Shift\n";
    cout<<"Press 6. for Right Shift\n";
    cout<<"Press 7. Exit\n";
    cin>>choice;

    switch(choice)
    {
    case 1:


        cout<<"Addition is:"<<a+b;
        break;

    case 2:

        cout<<"X-OR is:"<<(c^d);
        break;

    case 3:

        int number;

        cout<<"Enter any Number";
        cin>>number;

        (number%2)==0? cout<<"Number is Even": cout<<"Number is Odd";
        break;

    case 4:

        Largest = (e>f)?((e>g)?e:g): ((f>g)?f:g);

        cout<<"Largest Number is:"<<Largest;
        break;

    case 5:


        cout<<"Left Shift is:"<<(n<<2);
        break;

    case 6:


        cout<<"Right Shift is:"<<(n1>>2);
        break;

    case 7:
        exit(0);

    default:
        cout<<"You have entered the wrong case";

    }
        }

    return 0;
}
