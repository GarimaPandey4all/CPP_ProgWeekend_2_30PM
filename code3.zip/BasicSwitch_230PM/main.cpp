#include <iostream>

using namespace std;

int main()
{
    int a, b;

    char Operator;

    cout<<"Enter any Character:";
    cin>>Operator;

    switch(Operator)
    {
    case '+':

        cout<<"Enter values in a & b:";
        cin>>a>>b;

        cout<<"Sum is:"<<a+b<<endl;
        break;

    case '-':

        cout<<"Enter values in a & b";
        cin>>a>>b;

        cout<<"Subtraction is:"<<a-b<<endl;
        break;

    case '*':

        cout<<"Enter values in a & b";
        cin>>a>>b;

        cout<<"Multiplication is:"<<a*b<<endl;
        break;

    case '/':

        cout<<"Enter values in a & b";
        cin>>a>>b;

        cout<<"Division is:"<<a/b<<endl;
        break;

    case '%':

        cout<<"Enter values in a & b";
        cin>>a>>b;

        cout<<"Modulus is:"<<a%b<<endl;
        break;

    default:
        cout<<"You have entered the wrong operator";

    }

    return 0;
}
