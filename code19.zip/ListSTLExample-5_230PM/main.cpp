#include <iostream>
#include <list>

using namespace std;

int main()
{
    list <int> l1 {50, 90, 10, 30, 60};

    list <int> :: iterator p = l1.begin();

    while( p!= l1.end())
    {
        cout<<*p<<" ";
        ++p;
    }

    cout<<"\nTotal number of elements in a list are:"<<l1.size();

    cout<<endl;

    l1.sort();

    list <int> :: iterator p1 = l1.begin();

    while( p1!= l1.end())
    {
        cout<<*p1<<" ";
        ++p1;
    }

    cout<<"\nTotal number of elements in a list are:"<<l1.size();


    return 0;
}
