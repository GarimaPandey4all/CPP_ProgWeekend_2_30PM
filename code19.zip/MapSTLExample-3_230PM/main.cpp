#include <iostream>
#include <map>

using namespace std;

int main()
{
    map <int, string> customer; //only create a map

    customer[100] = "Garima";
    customer[145] = "Dilip";
    customer[235] = "Madhav";
    customer[101] = "Aakash";

    //OR second way is:

    map <int, string> c2 {{100, "Garima"}, {145, "Dilip"}, {235, "Madhav"}, {101, "Aakash"}};

    //Accessing values from the map: first way:

    cout<<"Customer 1:"<<customer[100]<<endl;
    cout<<"Customer 1:"<<customer[145]<<endl;
    cout<<"Customer 1:"<<customer[235]<<endl;
    cout<<"Customer 1:"<<customer[101]<<endl;

    //Insert using insert() in map:

    c2.insert(pair<int, string>(166, "Brain Mentors"));

    map <int, string> :: iterator p = c2.begin();

    while( p!= c2.end())
    {
        //cout<<p->second<<endl;
        cout<<p->first<<endl;
        ++p;
    }

    cout<<"Total number of elements:"<<c2.size()<<endl;

    return 0;
}
