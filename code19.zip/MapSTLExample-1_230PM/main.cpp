#include <iostream>
#include <map>

using namespace std;

int main()
{
    map <int, string> customer; //only create a map

    customer[100] = "Garima";
    customer[145] = "Dilip";
    customer[235] = "Madhav";
    customer[101] = "Aakash";

    //OR second way is:

    map <int, string> c2 {{100, "Garima"}, {145, "Dilip"}, {235, "Madhav"}, {101, "Aakash"}};


    return 0;
}
