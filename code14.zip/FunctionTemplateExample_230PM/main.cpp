#include <iostream>

using namespace std;

template <class T>
T Add(T a, T b)
{
    cout<<"Addition is:"<<a+b<<endl;
}


int main()
{
    Add(10, 20);
    Add(10.20, 30.6);

    return 0;
}
