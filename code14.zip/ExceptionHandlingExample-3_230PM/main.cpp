#include <iostream>

using namespace std;

int main()
{
    int a, b, c;

    cout<<"Enter any value for a and b:";
    cin>>a>>b;

    try
    {
        if(b==0)
        {
            throw "Division by Zero Error...";
        }

         c = a/b;

         cout<<"Division is:"<<c;

    }

    catch(const char* e)
    {
        cout<<e;
    }


    return 0;
}
