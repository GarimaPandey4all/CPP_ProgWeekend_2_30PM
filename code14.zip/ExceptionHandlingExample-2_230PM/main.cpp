#include <iostream>

using namespace std;


void Myfunc()
{
    throw 10;
}


int main()
{
    try{

    //throw "Exception...";

    Myfunc(); //function calling

    cout<<"Try Block.";

    }

//    catch(...)
//    {
//        cout<<"Exception here.";
//    }

    //3rd Way

    catch(int e)
    {
        cout<<"Value is:"<<e;
    }

    return 0;
}

