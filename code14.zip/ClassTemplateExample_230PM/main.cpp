#include <iostream>

using namespace std;

template <class T>
class Calculator
{
private:
    T a, b;

public:
    Calculator(T x, T y)
    {
        a = x;
        b = y;
    }

    void DisplayResult()
    {
        cout<<"Addition is:"<<a+b<<endl;
        cout<<"Subtraction is:"<<a-b<<endl;
        cout<<"Multiplication is:"<<a*b<<endl;
        cout<<"Division is:"<<a/b<<endl;
    }

};

int main()
{
    Calculator<int> C1(10, 20);
    Calculator<float> C2(10.30, 20.9);

    C1.DisplayResult();
    C2.DisplayResult();

    return 0;
}
