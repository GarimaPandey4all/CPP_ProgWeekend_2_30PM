#include <iostream>

using namespace std;

int main()
{
    int days[12]={31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}; //traditional way

    int days[12] = {31, 29, 31};

    int days[12] = {[5]=31, [9]=30}; //designated way

    int days[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}; //compile time initialization of array

    int days[][5]= {{5,7,8,9,9},
                    {4,5,6,7,7}};

    int days[][][]=

    int days[12];

    days[0]= 31;
    days[1]= 29;

    return 0;
}
