#include <iostream>

using namespace std;

/*

    1. For Loop

    for(initialization; condition; increment/decrement)
    {

    }

    initialization
    while(condition)
    {

    increment/ decrement
    }

    initialization
    do
    {
    increment/decrement

    }while(condition);


*/
