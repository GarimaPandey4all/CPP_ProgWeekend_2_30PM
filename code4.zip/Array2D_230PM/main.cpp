#include <iostream>

using namespace std;

int main()
{
    int matrix1[2][2],matrix2[2][2],result[2][2], i,j;

    cout<<"Enter any values in Matrix 1";
    for(i=0; i<2; i++)
    {
        for(j=0; j<2; j++)
        {
                cin>>matrix1[i][j];
        }
    }

    cout<<"Enter any values in Matrix 2";
    for(i=0; i<2; i++)
    {
        for(j=0; j<2; j++)
        {
                cin>>matrix2[i][j];
        }
    }

    cout<<"Enter any values in Matrix 1"<<endl;
    for(i=0; i<2; i++)
    {
        for(j=0; j<2; j++)
        {
                cout<<matrix1[i][j]<<"\t";
                if(j==1)
                    cout<<endl;
        }
    }

    cout<<"Enter any values in Matrix 2"<<endl;
    for(i=0; i<2; i++)
    {
        for(j=0; j<2; j++)
        {
                cout<<matrix2[i][j]<<"\t";
                if(j==1)
                    cout<<endl;
        }
    }

    for(i=0; i<2; i++)
    {
        for(j=0; j<2; j++)
        {
                result[i][j]= matrix1[i][j] + matrix2[i][j];
        }
    }

    cout<<"Addition is:"<<endl;
    for(i=0; i<2; i++)
    {
        for(j=0; j<2; j++)
        {
                cout<<result[i][j]<<"\t";
                if(j==1)
                    cout<<endl;
        }
    }

    return 0;
}
