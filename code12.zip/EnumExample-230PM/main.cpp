#include <iostream>

using namespace std;

int main()
{
    enum Week {Monday=1, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday};

    enum Week Today= Sunday;

    cout<<"Today is:"<<Today;

    return 0;
}
