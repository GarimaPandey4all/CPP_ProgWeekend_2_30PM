#include <iostream>

using namespace std;

struct Date
{
    int Day;
    int Month;
    int Year;
}date, date1, date2;

//struct Date date, date1, date2;

int main()
{
    date.Day = 1;
    date.Month =4;
    date.Year = 2020;

    cout<<"Day is:"<<date.Day<<" Month is:"<<date.Month<<" Year is:"<<date.Year;

    return 0;
}
