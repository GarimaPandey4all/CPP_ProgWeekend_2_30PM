#include <iostream>

using namespace std;

int main()
{
    int i = 10;
    float j = 2.34f;
    char z = 'A';

    void *vptr; //void pointer

    vptr = &i;
    cout<<"I is:"<<*(int *)vptr<<endl; //type-casting

    vptr = &j;
    cout<<"J is:"<<*(float *)vptr<<endl;

    vptr = &z;
    cout<<"Z is:"<<*(char *)vptr;

    return 0;
}
