#include <iostream>

using namespace std;

union Date
{
    int Day;
    int Month;
    int Year;
}date, date1, date2;

//struct Date date, date1, date2;

int main()
{
    date.Day = 1;
    cout<<"Day is:"<<date.Day<<endl;

    date.Month =4;
    cout<<"Month is:"<<date.Month<<endl;

    date.Year = 2020;
    cout<<"Year is:"<<date.Year;

    return 0;
}
