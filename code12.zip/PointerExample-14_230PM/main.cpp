#include <iostream>

using namespace std;

struct Date
{
    int Day;
    int Month;
    int Year;
};

struct Date date, *pdate;

int main()
{
    pdate = &date;

    pdate->Day = 2;
    pdate->Month = 3;
    pdate->Year = 2020;

    cout<<"Day "<<pdate->Day<<" Month "<<pdate->Month<<" Year "<<pdate->Year;

    return 0;
}
