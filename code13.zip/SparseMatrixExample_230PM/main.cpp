#include <iostream>

using namespace std;

int main()
{
    int matrix[10][10], i, j, Total=0, rows, columns;

    cout<<"Enter number of rows:";
    cin>>rows;

    cout<<"Enter number of columns";
    cin>>columns;

    cout<<"Enter values in Matrix:";
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            cin>>matrix[i][j];
        }
    }

    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            if(matrix[i][j]==0)
                ++Total;
        }
    }

    if(Total> (rows * columns)/2)
        cout<<"It is sparse Matrix.";
    else
        cout<<"It is not a sparse Matrix.";

    return 0;
}
