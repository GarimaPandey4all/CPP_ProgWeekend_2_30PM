#include <iostream>

using namespace std;

void swap(int*, int*); //function declaration

void swap(int *a, int *b) //function definition
{
    int temp = *a;
    *a = *b;
    *b = temp;
}

int main()
{
    int a = 45, b = 35;
    cout << "Before Swap\n";
    cout << "a = " << a << " b = " << b << "\n";

    swap(&a, &b); //function calling

    cout << "After Swap with pass by pointer\n";
    cout << "a = " << a << " b = " << b << "\n";
}
