#include <iostream>

using namespace std;

int main()
{
    int a[10][10], b[10][10], i, j, count=1, rows, columns;

    cout<<"Enter number of rows:";
    cin>>rows;

    cout<<"Enter number of columns";
    cin>>columns;

    cout<<"Enter values in Matrix:";
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            cin>>a[i][j];
        }
    }

   //Transpose of a Matrix

   for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            b[j][i] = a[i][j];
        }
    }

    cout<<"Transpose Matrix:"<<endl;
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            cout<<b[i][j]<<"\t";
        }
        cout<<endl;
    }

    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            if(a[i][j] != b[i][j])
            {
                ++count;
                break;
            }
        }
    }

    if(count == 1)
        cout<<"Matrix is Symmetric.";

    else
        cout<<"Matrix is not Symmetric.";

    return 0;
}
