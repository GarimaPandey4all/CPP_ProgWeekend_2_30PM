#include <iostream>

using namespace std;

class Myclass
{
public:

    Myclass()
    {
        cout<<"I'm Constructor"<<endl;
    }
};

int main()
{
    Myclass C1;
    Myclass C2;
    Myclass C3;

    return 0;
}
