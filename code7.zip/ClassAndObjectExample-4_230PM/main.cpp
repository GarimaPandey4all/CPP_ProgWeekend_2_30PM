#include <iostream>

using namespace std;


/*

    Access Specifiers:

    1. Public:
    2. Private:
    3. Protected:


*/


class VarAssign
{

    int y;

public:
    int x;

};


int main()
{
    VarAssign v1;

    v1.x = 10;

    //v1.y = 20; //Error

    cout<<"X is:"<<v1.x<<endl;
    //cout<<"Y is:"<<v1.y;

    return 0;
}
