#include <iostream>

using namespace std;

/*

    1. Function definition inside the class
    2. Function definition outside the class

*/


class HelloWorld
{
public:

    void ShowData(); //function declaration
};

void HelloWorld::ShowData()
{
    cout<<"Hello World.";
}

int main()
{
    HelloWorld h1;
    h1.ShowData();

    return 0;
}
