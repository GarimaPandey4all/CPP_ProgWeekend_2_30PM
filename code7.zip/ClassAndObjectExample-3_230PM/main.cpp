#include <iostream>

using namespace std;

class VarAssign
{
public:
    int x;

private:
    int y;
};


int main()
{
    VarAssign v1;

    v1.x = 10;

    //v1.y = 20; //Error

    cout<<"X is:"<<v1.x<<endl;
    //cout<<"Y is:"<<v1.y;

    return 0;
}
