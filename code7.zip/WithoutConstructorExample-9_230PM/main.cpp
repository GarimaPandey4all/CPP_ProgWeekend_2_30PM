#include <iostream>

using namespace std;

class Car
{
public:

    string Brand;
    string Model;
    string Year;

    void MyCar(string x, string y, string z)
    {
        Brand = x;
        Model = y;
        Year = z;
    }
};


int main()
{
    Car C1;
    C1.MyCar("Maruti Suzuki", "C5", "2019");

    cout<<"Brand is:"<<C1.Brand<<endl;
    cout<<"Model is:"<<C1.Model<<endl;
    cout<<"Year is:"<<C1.Year<<endl;

    return 0;
}
