#include <iostream>

using namespace std;

//Friend function example

class Complex
{
private:
    int a, b;

public:
    void setData(int x, int y)
    {
        a = x;
        b = y;
    }

    void showData()
    {
        cout<<"a:"<<a<<" b:"<<b<<endl;
    }

    friend void func(Complex); //Friend function declaration by using friend keyword
};

void func(Complex c) // Friend function definition outside the class
{
    cout<<"Sum is:"<<c.a+c.b;
}

int main()
{

    Complex obj; //creating a object of class "Complex"
    obj.setData(10, 30); //calling normal member function

    func(obj); //calling friend function by using class's object

    return 0;
}
