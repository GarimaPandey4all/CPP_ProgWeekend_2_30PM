#include <iostream>

using namespace std;

//Static variable inside function but without using class

void updateCount()
{
    static int count; //same as static int count = 0;
    cout<<count++<<" ";
}

int main()
{
    for(int i=0; i<5; i++)
        updateCount();

    return 0;
}
