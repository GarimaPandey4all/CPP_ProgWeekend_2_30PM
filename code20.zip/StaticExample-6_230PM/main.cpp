#include <iostream>

using namespace std;

//Static Member function in a class

class Demo
{
public:
    static void func() //static member function
    {
        cout<<"This is static member function block.";
    }
};

int main()
{
    Demo :: func(); //calling member function directly with class name

    return 0;
}
