#include <iostream>

using namespace std;

//Static Data Member in Class

class Employee
{
public:
    static int age;

    Employee() //constructor
    {
        cout<<"Age is:"<<age; //one way to print static value
    }
};

int Employee :: age = 25; //Define static variable outside the class

int main()
{
    Employee obj;

    cout<<"Age is:"<<obj.age; //second way to print static value

    return 0;
}
