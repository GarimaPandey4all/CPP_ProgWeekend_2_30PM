#include <iostream>

using namespace std;

class student
{
private:
    int rollno; //instance variable
    static int marks; //static variable/class member variable

public:

    void setData(int r)
    {
        rollno = r;
    }

    void showData()
    {
        cout<<"Roll no is:"<<rollno<<endl;
        cout<<"Marks is:"<<marks<<endl;
    }
};

int student :: marks= 525; //initialization/definition of static variable

int main()
{
    student s1;
    s1.setData(12);
    s1.showData();

    return 0;
}
