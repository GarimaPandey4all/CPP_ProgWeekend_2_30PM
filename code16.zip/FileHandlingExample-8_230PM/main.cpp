#include <iostream>
#include <fstream>
using namespace std;

//Content add at particular position


int main()
{
    int position;
    fstream file;

    file.open("Test.txt");

    //write content in a file
    file.write("This is an apple.", 17);

    position = file.tellp();

    //set pointer position
    file.seekp(position - 8);
    file.write(" sam", 4);
    file.close();

    return 0;
}
