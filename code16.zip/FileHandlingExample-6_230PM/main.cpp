#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    fstream file;

    file.open("Test.txt", ios::out);

    if(!file)
    {
        cout<<"Opening file Error.";
        exit(0);
    }

    file<<"This is output file example with tellp().";

    cout<<"Current position of pointer is:"<<file.tellp()<<endl;

    file.close();

    //Re-open the file

    file.open("Test.txt", ios::in);

    if(!file)
    {
        cout<<"Opening file Error.";
        exit(0);
    }

    cout<<"After opening file position is:"<<file.tellg();

    file.close();

    return 0;
}
